import NosCafes from "./nosCafes";

export const metadata = {
  title: "Nos cafés | Coffee House",
  description:
    "Découvrez notre sélection de cafés artisanaux chez Coffee House.",
};

export default function Page() {
  return <NosCafes />;
}